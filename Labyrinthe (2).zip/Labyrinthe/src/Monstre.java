import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

//import javax.swing.Timer;
import javax.swing.JPanel;

public class Monstre { //implements ActionListener{
	public int x=70*5;
	public int y;
	public Image image_monstre;
	static int dx=25;
	static int dy=25;
//	private Timer timer;
	public boolean enVie=true;
	
	public int getX() {
		return x;
	}


	public void setX(int x) {
		this.x = x;
	}


	public int getY() {
		return y;
	}


	public void setY(int y) {
		this.y = y;
	}

	void move() {
//		timer = new Timer(5000, (ActionListener) this);
//		timer.start();
		Timer t = new Timer();
        t.schedule(new TimerTask() {
            @Override
            public void run() {
            	Random random = new Random();
    			ArrayList<String> choix = new ArrayList();
    			choix.add("Left");
    			choix.add("Right");
    			choix.add("Up");
    			choix.add("Down");
    			String direction = choix.get(random.nextInt(choix.size()));
    			
    			switch (direction) {
    			case "Left":
    				moveLeft(dx);
    				break;
    			case "Right":
    				moveRight(dx);
    				break;
    			case "Up":
    				moveUp(dy);
    				break;
    			case "Down":
    				moveDown(dy);
    				break;
    		}
            }
        }, 0, 5000); 
        
    }
		
		
	
	void moveRight(int dx) {
		// TODO Auto-generated method stub
		setX(x+dx);
	}


	void moveLeft(int dx) {
		// TODO Auto-generated method stub
		setX(x-dx);
	}


	void moveDown(int dy) {
		// TODO Auto-generated method stub
		setY(y+dy);
	}


	void moveUp(int dy) {
		// TODO Auto-generated method stub
		setY(y-dy);
	}

	void reset() {
		x=25*10;
		y=25*5;
		enVie=true;
	}


	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
